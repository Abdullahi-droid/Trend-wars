# Trend Wars

Full-stack mobile app: React Native frontend + FastAPI backend.
