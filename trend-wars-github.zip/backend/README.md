# Trend Wars API

Run: `uvicorn main:app --reload`
