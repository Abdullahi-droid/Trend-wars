# Trend Wars App (Expo)

Run: `npm install && npm start`
